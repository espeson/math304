MSE_Result_Digit=[];
for i=1:5
    Parameter=LSR_xc166(SmallData,power(10,-6)*power(10.^3,i-1),9);
    %Start to create functions
    syms x
    list=[];
    for a=0:size(Parameter)-1
        list=[list power(x,a)];
    end
    f(x)=Parameter'*list';
    %end of creating functions and start to plot 
    fplot(f(x),[0 1])
    hold on
    x_DataPoint_SmallData=SmallData(1,:);
    y_DataPoint_SmallData=SmallData(2,:);
    plot(x_DataPoint_SmallData,y_DataPoint_SmallData,'.')
    %end of plot and start to calculate the Training error
    MSE_Matrix_Temporary=[];
    for b=1:size(x_DataPoint_SmallData,2)
        MSE=power(y_DataPoint_SmallData(b)-f(x_DataPoint_SmallData(b)),2);
        MSE_Matrix_Temporary=[MSE_Matrix_Temporary MSE];
    end
    MSE_Result_Digit=[MSE_Result_Digit sum(MSE_Matrix_Temporary)/size(x_DataPoint_SmallData,2)];
end
MSE_Result_Digit=vpa(MSE_Result_Digit)